<?php
$val1 = isset($_GET['val1']) ? $_GET['val1'] : '';
$val2 = isset($_GET['val2']) ? $_GET['val2'] : '';
$trimmed = trim($val1);
$processed1 = strrev($trimmed); 
$search = array('E', 'e', 'Е', 'е');
$processed2 = str_replace($search, 'H', $val2);
$method = $_SERVER['REQUEST_METHOD'];
$ip = $_SERVER['REMOTE_ADDR'];
$referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'Прямой переход';
echo <<<RESULT
    <h3>Результаты работы скрипта:</h3>
    <p>Первое значение (реверс): $processed1</p>
    <p>Второе значение (замена E на H): $processed2</p>
    <table border="1" style="border-collapse: collapse;">
        <tr>
            <td>Метод запроса</td>
            <td>$method</td>
        </tr>
        <tr>
            <td>IP-адрес пользователя</td>
            <td>$ip</td>
        </tr>
        <tr>
            <td>Адрес страницы перехода</td>
            <td>$referer</td>
        </tr>
    </table>
RESULT;
?>